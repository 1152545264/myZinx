package ziface

import "net"

// IConnection 定义连接模块的抽象
type IConnection interface {
	// Start 启动连接
	Start()

	// Stop 停止连接
	Stop()

	// GetTCPConnection 获取当前连接绑定的socket
	GetTCPConnection() *net.TCPConn

	// GetConnID 获取当前连接模块的连接ID
	GetConnID() uint32

	// GetRemoteAddr 获取远程客户端的TCP状态 IP和Port
	GetRemoteAddr() net.Addr

	// Send 发送数据，将数据发送给远程的客户端
	Send(data []byte) error
}

// HandleFunc 定义一个处理连接业务的方法
type HandleFunc func(*net.TCPConn, []byte, int) error
